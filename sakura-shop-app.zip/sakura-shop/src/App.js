import './App.css';
import { BrowserRouter, Routes, Route, NavLink, useLocation } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Portal from './pages/Portal';
import LoyaltyTiers from './pages/LoyaltyTiers';
import Promotions from './pages/Promotions';

const PAGE_TITLES = {
  '/': 'Dashboard',
  '/customers': 'All Customers',
  '/portal': 'Customer Portal',
  '/tiers': 'Loyalty Tiers',
  '/promotions': 'Promotions & Gifts',
};

function Topbar() {
  const loc = useLocation();
  const title = PAGE_TITLES[loc.pathname] || 'Sakura Shop';
  return (
    <div className="topbar">
      <span className="topbar-title">{title}</span>
      <div className="topbar-right">
        <span className="live-badge">🌸 Live · 219 customers</span>
        <span style={{ fontSize: 12, color: 'var(--text3)' }}>USD · Cambodia</span>
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div className="sidebar-logo-mark">Sakura Shop</div>
        <div className="sidebar-logo-sub">Business Manager</div>
      </div>

      <div className="sidebar-section">Main</div>
      <NavLink to="/" end className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>
        <i className="ti ti-layout-dashboard" aria-hidden="true" /> Dashboard
      </NavLink>

      <div className="sidebar-section">Customers</div>
      <NavLink to="/customers" className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>
        <i className="ti ti-users" aria-hidden="true" /> All customers
      </NavLink>
      <NavLink to="/portal" className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>
        <i className="ti ti-id-badge" aria-hidden="true" /> Customer portal
      </NavLink>

      <div className="sidebar-section">Loyalty</div>
      <NavLink to="/tiers" className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>
        <i className="ti ti-star" aria-hidden="true" /> Tier rules
      </NavLink>
      <NavLink to="/promotions" className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>
        <i className="ti ti-gift" aria-hidden="true" /> Promotions & gifts
      </NavLink>

      <div style={{ marginTop: 'auto', padding: '1rem 1.25rem', borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text3)' }}>
        Data: Positems 2025<br />
        Built with ♥ for Sakura Shop
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-layout">
        <Sidebar />
        <div className="main">
          <Topbar />
          <div className="page-content">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/customers" element={<Customers />} />
              <Route path="/portal" element={<Portal />} />
              <Route path="/tiers" element={<LoyaltyTiers />} />
              <Route path="/promotions" element={<Promotions />} />
            </Routes>
          </div>
        </div>
      </div>
    </BrowserRouter>
  );
}
