export const TIER_EMOJI = { VIP: '⭐', Gold: '🥇', Silver: '🥈', Bronze: '🥉' };
export const TIER_DISCOUNT = { VIP: 15, Gold: 10, Silver: 5, Bronze: 2 };
export const TIER_PTS_MULT = { VIP: 2, Gold: 1.5, Silver: 1.2, Bronze: 1 };

export function initials(name) {
  return name.split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

export function tierColor(tier) {
  return { VIP: 'vip', Gold: 'gold', Silver: 'silver', Bronze: 'bronze' }[tier] || 'bronze';
}

export function fmtUSD(n) {
  return '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

export function fmtPts(n) {
  return Number(n).toLocaleString() + ' pts';
}

export function progressPct(customer) {
  const { tier, total_spend } = customer;
  if (tier === 'VIP') return 100;
  const ranges = { Gold: [300, 500], Silver: [100, 300], Bronze: [0, 100] };
  const [min, max] = ranges[tier];
  return Math.min(100, Math.round(((total_spend - min) / (max - min)) * 100));
}

export function tierFromSpend(spend) {
  if (spend >= 500) return 'VIP';
  if (spend >= 300) return 'Gold';
  if (spend >= 100) return 'Silver';
  return 'Bronze';
}
