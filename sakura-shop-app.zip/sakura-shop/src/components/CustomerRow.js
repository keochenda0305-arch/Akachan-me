import { initials, tierColor, fmtUSD, fmtPts, TIER_EMOJI } from '../utils';

export default function CustomerRow({ customer, onClick }) {
  const tc = tierColor(customer.tier);
  return (
    <div className="cust-row" style={{ cursor: onClick ? 'pointer' : 'default' }} onClick={() => onClick && onClick(customer)}>
      <div className={`avatar av-${tc}`}>{initials(customer.name)}</div>
      <div className="cust-info">
        <div className="cust-name">{customer.name}</div>
        <div className="cust-meta">{customer.order_count} orders · {fmtUSD(customer.total_spend)} spent · last: {customer.last_order || '—'}</div>
      </div>
      <span className={`tier-pill tp-${customer.tier}`}>{TIER_EMOJI[customer.tier]} {customer.tier}</span>
      <div style={{ fontSize: 12, color: 'var(--text3)', textAlign: 'right', minWidth: 70 }}>
        {fmtPts(customer.points)}
      </div>
    </div>
  );
}
