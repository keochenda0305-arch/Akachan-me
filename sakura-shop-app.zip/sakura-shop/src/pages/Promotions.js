import { useState } from 'react';

const OCCASIONS = ['Khmer New Year', 'Pchum Ben', 'Water Festival', 'Christmas', 'New Year'];

export default function Promotions() {
  const [msg, setMsg] = useState('');
  const [tiers, setTiers] = useState({ VIP: true, Gold: true, Silver: false, Bronze: false });
  const [occasion, setOccasion] = useState('');

  const toggleTier = t => setTiers(prev => ({ ...prev, [t]: !prev[t] }));
  const targetCount = { VIP: 25, Gold: 11, Silver: 41, Bronze: 142 };
  const total = Object.entries(tiers).filter(([, v]) => v).reduce((s, [t]) => s + targetCount[t], 0);

  return (
    <div>
      <div className="two-col">
        <div className="card">
          <div className="card-title">Occasion message</div>
          <div style={{ marginBottom: '0.75rem' }}>
            <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6 }}>Occasion</div>
            <select
              className="select-input"
              style={{ marginBottom: 0 }}
              value={occasion}
              onChange={e => setOccasion(e.target.value)}
            >
              <option value="">— Select occasion —</option>
              {OCCASIONS.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>

          <div style={{ marginBottom: '0.75rem' }}>
            <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6 }}>Send to tiers</div>
            <div style={{ display: 'flex', gap: 8 }}>
              {Object.keys(tiers).map(t => (
                <button
                  key={t}
                  className={`filter-btn${tiers[t] ? ' active' : ''}`}
                  onClick={() => toggleTier(t)}
                >
                  {t}
                </button>
              ))}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 6 }}>
              {total} customers will receive this message
            </div>
          </div>

          <div style={{ marginBottom: '0.75rem' }}>
            <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6 }}>Your personal message</div>
            <textarea
              style={{
                width: '100%',
                minHeight: 120,
                padding: '9px 12px',
                border: '1px solid var(--border2)',
                borderRadius: 'var(--radius)',
                background: 'var(--bg2)',
                color: 'var(--text)',
                fontFamily: 'var(--font)',
                fontSize: 13,
                resize: 'vertical',
                outline: 'none',
              }}
              placeholder={`Write your ${occasion || 'occasion'} message here...\n\nExample: Happy Khmer New Year! 🎉 Thank you so much for your support. As our valued VIP customer, enjoy 20% off this week. Wishing you joy and happiness! 🌸`}
              value={msg}
              onChange={e => setMsg(e.target.value)}
            />
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-primary btn-sm">
              <i className="ti ti-send" style={{ verticalAlign: -2, marginRight: 4 }} aria-hidden="true" />
              Mark as sent ({total})
            </button>
            <button className="btn btn-sm" onClick={() => setMsg('')}>Clear</button>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Birthday gifts schedule</div>
          <div style={{ fontSize: 13, lineHeight: 1.9, color: 'var(--text2)' }}>
            <div style={{ marginBottom: 12 }}>When a customer's birthday arrives, they automatically receive:</div>
            {[
              { tier: 'VIP ⭐', gift: '500 pts + 15% coupon + your personal message' },
              { tier: 'Gold 🥇', gift: '200 pts + 10% coupon' },
              { tier: 'Silver 🥈', gift: '100 pts + 5% coupon' },
              { tier: 'Bronze 🥉', gift: '50 bonus points' },
            ].map(r => (
              <div key={r.tier} style={{ display: 'flex', gap: 12, padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ minWidth: 80, fontWeight: 500, color: 'var(--text)' }}>{r.tier}</div>
                <div>{r.gift}</div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12, fontSize: 12, color: 'var(--text3)' }}>
            <i className="ti ti-info-circle" style={{ verticalAlign: -2, marginRight: 4 }} aria-hidden="true" />
            Add birthdays to each customer profile to activate this feature
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Monthly spend target — auto coupons</div>
        <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.9, marginBottom: '1rem' }}>
          At the end of each month, customers who hit a spend target automatically get a coupon code to use on their next order.
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {[
            { target: '$150/month', coupon: '$2 off', color: 'var(--bronze-bg)', text: 'var(--bronze-text)' },
            { target: '$300/month', coupon: '$5 off', color: 'var(--silver-bg)', text: 'var(--silver-text)' },
            { target: '$500/month', coupon: '$10 off', color: 'var(--gold-bg)', text: 'var(--gold-text)' },
          ].map(r => (
            <div key={r.target} style={{ background: r.color, borderRadius: 'var(--radius-lg)', padding: '1rem', textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-serif)', fontSize: 26, color: r.text }}>{r.coupon}</div>
              <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4 }}>when spending {r.target}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
