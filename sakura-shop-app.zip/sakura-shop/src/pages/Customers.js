import { useState, useMemo } from 'react';
import customers from '../data/customers.json';
import CustomerRow from '../components/CustomerRow';
import { TIER_EMOJI } from '../utils';

const TIERS = ['All', 'VIP', 'Gold', 'Silver', 'Bronze'];
const PAGE_SIZE = 30;

export default function Customers() {
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState('All');
  const [limit, setLimit] = useState(PAGE_SIZE);

  const tierCounts = useMemo(() => {
    return customers.reduce((acc, c) => { acc[c.tier] = (acc[c.tier] || 0) + 1; return acc; }, {});
  }, []);

  const filtered = useMemo(() => {
    return customers.filter(c => {
      if (tierFilter !== 'All' && c.tier !== tierFilter) return false;
      if (search && !c.name.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [search, tierFilter]);

  const shown = filtered.slice(0, limit);

  return (
    <div>
      <div className="card">
        <div className="search-wrap">
          <i className="ti ti-search" aria-hidden="true" />
          <input
            className="search-box"
            placeholder="Search customer name..."
            value={search}
            onChange={e => { setSearch(e.target.value); setLimit(PAGE_SIZE); }}
          />
        </div>

        <div className="filter-row">
          {TIERS.map(t => (
            <button
              key={t}
              className={`filter-btn${tierFilter === t ? ' active' : ''}`}
              onClick={() => { setTierFilter(t); setLimit(PAGE_SIZE); }}
            >
              {t === 'All' ? 'All customers' : `${TIER_EMOJI[t]} ${t} (${tierCounts[t] || 0})`}
            </button>
          ))}
        </div>

        <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: '0.75rem' }}>
          Showing {shown.length} of {filtered.length} customers
        </div>

        {shown.map(c => <CustomerRow key={c.uid} customer={c} />)}

        {filtered.length > limit && (
          <div style={{ textAlign: 'center', marginTop: '1rem' }}>
            <button className="btn btn-sm" onClick={() => setLimit(l => l + PAGE_SIZE)}>
              Load more ({filtered.length - limit} remaining)
            </button>
          </div>
        )}

        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text3)' }}>
            No customers found
          </div>
        )}
      </div>
    </div>
  );
}
