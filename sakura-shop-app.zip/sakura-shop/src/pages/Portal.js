import { useState } from 'react';
import customers from '../data/customers.json';
import { initials, tierColor, fmtUSD, fmtPts, progressPct, TIER_EMOJI, TIER_DISCOUNT, TIER_PTS_MULT } from '../utils';

export default function Portal() {
  const [selectedUid, setSelectedUid] = useState('');
  const customer = customers.find(c => c.uid === selectedUid);

  const redeemableValue = customer && customer.points >= 500
    ? Math.floor(customer.points / 100)
    : 0;

  const pct = customer ? progressPct(customer) : 0;

  return (
    <div>
      <div className="card" style={{ marginBottom: '1rem' }}>
        <div className="card-title">Preview — what a customer sees when you send them their link</div>
        <select
          className="select-input"
          value={selectedUid}
          onChange={e => setSelectedUid(e.target.value)}
        >
          <option value="">— Select a customer to preview —</option>
          {customers.map(c => (
            <option key={c.uid} value={c.uid}>
              {c.name} ({c.tier} · {c.points.toLocaleString()} pts)
            </option>
          ))}
        </select>
        {selectedUid && (
          <div style={{ fontSize: 12, color: 'var(--text3)' }}>
            <i className="ti ti-link" style={{ verticalAlign: -2 }} aria-hidden="true" /> Customer link would be:
            <code style={{ marginLeft: 6, background: 'var(--bg2)', padding: '2px 8px', borderRadius: 4 }}>
              yourshop.vercel.app/member/{selectedUid}
            </code>
          </div>
        )}
      </div>

      {customer && (
        <div>
          {/* Loyalty Card */}
          <div className={`loyalty-card lc-${customer.tier}`} style={{ marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
              <div className={`avatar av-${tierColor(customer.tier)}`} style={{ width: 48, height: 48, fontSize: 15 }}>
                {initials(customer.name)}
              </div>
              <div>
                <div style={{ fontFamily: 'var(--font-serif)', fontSize: 20, color: `var(--${tierColor(customer.tier)}-text)` }}>
                  {customer.name}
                </div>
                <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 2 }}>
                  {TIER_EMOJI[customer.tier]} {customer.tier} Member · Sakura Shop 🌸
                </div>
              </div>
            </div>

            <div className="stat-mini-grid">
              <div className="stat-mini">
                <div className="stat-mini-val">{customer.points.toLocaleString()}</div>
                <div className="stat-mini-lbl">Points</div>
              </div>
              <div className="stat-mini">
                <div className="stat-mini-val">{fmtUSD(customer.total_spend)}</div>
                <div className="stat-mini-lbl">Total spent</div>
              </div>
              <div className="stat-mini">
                <div className="stat-mini-val">{customer.order_count}</div>
                <div className="stat-mini-lbl">Orders</div>
              </div>
            </div>

            {customer.tier !== 'VIP' && (
              <div style={{ marginTop: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text2)', marginBottom: 4 }}>
                  <span>Progress to {customer.next_tier.name}</span>
                  <span>{fmtUSD(customer.next_tier.needed)} more to go</span>
                </div>
                <div className="progress-wrap" style={{ height: 7 }}>
                  <div className={`progress-fill pf-${customer.tier}`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            )}
            {customer.tier === 'VIP' && (
              <div style={{ marginTop: 12, fontSize: 13, color: 'var(--text2)' }}>
                You are at the highest tier! Thank you for your loyalty. 💖
              </div>
            )}
          </div>

          {/* Points & Rewards */}
          <div className="two-col">
            <div className="card">
              <div className="card-title">Points & redemption</div>
              <div style={{ fontSize: 13, lineHeight: 2, color: 'var(--text2)' }}>
                <div>Balance: <strong style={{ color: 'var(--text)' }}>{fmtPts(customer.points)}</strong></div>
                <div>Redeemable value: <strong style={{ color: 'var(--accent)' }}>{fmtUSD(redeemableValue)} off</strong></div>
                {customer.points < 500 && (
                  <div style={{ fontSize: 11, color: 'var(--text3)' }}>
                    Need {500 - customer.points} more pts to redeem
                  </div>
                )}
                <div style={{ marginTop: 8 }}>Points multiplier: <strong style={{ color: 'var(--text)' }}>{TIER_PTS_MULT[customer.tier]}× per $1</strong></div>
                <div>Tier discount: <strong style={{ color: 'var(--text)' }}>{TIER_DISCOUNT[customer.tier]}% off every order</strong></div>
              </div>
            </div>

            <div className="card">
              <div className="card-title">Coupons available</div>
              {redeemableValue > 0 ? (
                <div className="coupon">
                  <div className="coupon-value">{fmtUSD(redeemableValue)}</div>
                  <div className="coupon-detail">
                    <div className="coupon-title">Points redemption coupon</div>
                    <div className="coupon-sub">Use on your next order · mention to Sakura Shop</div>
                  </div>
                </div>
              ) : (
                <div style={{ fontSize: 13, color: 'var(--text3)', padding: '0.5rem 0' }}>
                  No coupons yet. Keep shopping to earn more points!
                </div>
              )}
              {customer.tier === 'VIP' && (
                <div className="coupon" style={{ marginTop: 8 }}>
                  <div className="coupon-value" style={{ fontSize: 20 }}>🎁</div>
                  <div className="coupon-detail">
                    <div className="coupon-title">VIP early access</div>
                    <div className="coupon-sub">You get first pick of new products</div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {customer.address && (
            <div className="card">
              <div className="card-title">Contact info</div>
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.8 }}>
                {customer.phone && <div><i className="ti ti-phone" style={{ fontSize: 14, verticalAlign: -2, marginRight: 6 }} aria-hidden="true" />{customer.phone}</div>}
                {customer.address && <div><i className="ti ti-map-pin" style={{ fontSize: 14, verticalAlign: -2, marginRight: 6 }} aria-hidden="true" />{customer.address}</div>}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
