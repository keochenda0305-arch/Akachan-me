import { useMemo } from 'react';
import customers from '../data/customers.json';
import CustomerRow from '../components/CustomerRow';
import { fmtUSD, fmtPts, TIER_EMOJI } from '../utils';

export default function Dashboard() {
  const stats = useMemo(() => {
    const totalRevenue = customers.reduce((s, c) => s + c.total_spend, 0);
    const totalOrders = customers.reduce((s, c) => s + c.order_count, 0);
    const totalPoints = customers.reduce((s, c) => s + c.points, 0);
    const tierCounts = customers.reduce((acc, c) => { acc[c.tier] = (acc[c.tier] || 0) + 1; return acc; }, {});
    return { totalRevenue, totalOrders, totalPoints, tierCounts };
  }, []);

  const topVIP = customers.filter(c => c.tier === 'VIP').slice(0, 5);

  const nearNextTier = customers
    .filter(c => c.next_tier.needed > 0 && c.next_tier.needed <= 60)
    .sort((a, b) => a.next_tier.needed - b.next_tier.needed)
    .slice(0, 6);

  const tiers = ['VIP', 'Gold', 'Silver', 'Bronze'];
  const maxCount = Math.max(...tiers.map(t => stats.tierCounts[t] || 0));

  return (
    <div>
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-label">Total customers</div>
          <div className="metric-value">{customers.length}</div>
          <div className="metric-sub">from Positems 2025</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Revenue 2025</div>
          <div className="metric-value">{fmtUSD(stats.totalRevenue)}</div>
          <div className="metric-sub">all transactions</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Total orders</div>
          <div className="metric-value">{stats.totalOrders.toLocaleString()}</div>
          <div className="metric-sub">across all customers</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Points issued</div>
          <div className="metric-value">{(stats.totalPoints / 1000).toFixed(1)}k</div>
          <div className="metric-sub">loyalty points total</div>
        </div>
      </div>

      <div className="two-col">
        <div className="card">
          <div className="card-title">Top VIP customers</div>
          {topVIP.map(c => <CustomerRow key={c.uid} customer={c} />)}
        </div>

        <div className="card">
          <div className="card-title">Tier breakdown</div>
          {tiers.map(t => (
            <div key={t} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                <span style={{ color: 'var(--text2)' }}>{TIER_EMOJI[t]} {t}</span>
                <span style={{ fontWeight: 500 }}>{stats.tierCounts[t] || 0} customers</span>
              </div>
              <div className="progress-wrap">
                <div className={`progress-fill pf-${t}`} style={{ width: `${Math.round(((stats.tierCounts[t] || 0) / maxCount) * 100)}%` }} />
              </div>
            </div>
          ))}
          <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)', fontSize: 12, color: 'var(--text3)' }}>
            Total points issued: <strong style={{ color: 'var(--text)' }}>{fmtPts(stats.totalPoints)}</strong>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Close to next tier — great customers to reach out to!</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
          {nearNextTier.map(c => (
            <div key={c.uid} className="cust-row">
              <div className={`avatar av-${c.tier.toLowerCase()}`} style={{ width: 32, height: 32, fontSize: 11 }}>
                {c.name.split(' ').map(w => w[0]).join('').slice(0, 2)}
              </div>
              <div className="cust-info">
                <div className="cust-name">{c.name}</div>
                <div className="cust-meta" style={{ color: 'var(--accent)', fontWeight: 500 }}>
                  {fmtUSD(c.next_tier.needed)} more → {c.next_tier.name}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
