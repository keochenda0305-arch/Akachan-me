import { TIER_EMOJI, TIER_DISCOUNT, TIER_PTS_MULT } from '../utils';

const TIERS = [
  { name: 'VIP', threshold: '$500+', count: 25, perks: ['15% discount on every order', '2× points per $1 spent', 'Early access to new products', 'Personal birthday message', '500 bonus birthday points'] },
  { name: 'Gold', threshold: '$300–$499', count: 11, perks: ['10% discount on every order', '1.5× points per $1 spent', 'Priority support', '200 bonus birthday points', '10% birthday coupon'] },
  { name: 'Silver', threshold: '$100–$299', count: 41, perks: ['5% discount on every order', '1.2× points per $1 spent', 'Standard support', '100 bonus birthday points', '5% birthday coupon'] },
  { name: 'Bronze', threshold: '$1–$99', count: 142, perks: ['2% discount on every order', '1× point per $1 spent', 'Welcome tier', '50 bonus birthday points'] },
];

export default function LoyaltyTiers() {
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
        {TIERS.map(t => (
          <div key={t.name} className={`loyalty-card lc-${t.name}`}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <div>
                <div className="lc-tier-name">{TIER_EMOJI[t.name]} {t.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>Spend {t.threshold} total</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 20, fontWeight: 600, color: 'var(--text)' }}>{t.count}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)' }}>customers</div>
              </div>
            </div>
            <ul style={{ listStyle: 'none', fontSize: 13, lineHeight: 1.9, color: 'var(--text2)' }}>
              {t.perks.map(p => (
                <li key={p}><i className="ti ti-check" style={{ fontSize: 13, marginRight: 6, color: 'var(--accent)' }} aria-hidden="true" />{p}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-title">Points system</div>
        <div style={{ fontSize: 13, lineHeight: 2, color: 'var(--text2)' }}>
          <div><strong style={{ color: 'var(--text)' }}>Earning:</strong> 1 base point per $1 spent (before discount), multiplied by tier rate</div>
          <div><strong style={{ color: 'var(--text)' }}>Redeeming:</strong> 100 points = $1 off next order</div>
          <div><strong style={{ color: 'var(--text)' }}>Minimum redemption:</strong> 500 points = $5 off</div>
          <div><strong style={{ color: 'var(--text)' }}>Expiry:</strong> Points expire after 12 months of inactivity</div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Monthly spend target coupons</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { spend: '$150+', reward: '$2 coupon', note: 'Auto-generated at month end' },
            { spend: '$300+', reward: '$5 coupon', note: 'Auto-generated at month end' },
            { spend: '$500+', reward: '$10 coupon + tier review', note: 'Eligible for VIP upgrade' },
          ].map(r => (
            <div key={r.spend} className="coupon">
              <div className="coupon-value" style={{ fontSize: 20, minWidth: 50 }}>{r.reward.split(' ')[0]}</div>
              <div className="coupon-detail">
                <div className="coupon-title">Spend {r.spend} in a month → {r.reward}</div>
                <div className="coupon-sub">{r.note}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
