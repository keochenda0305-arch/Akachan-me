# 🌸 Sakura Shop — Business Manager

Your loyalty & customer management web app — built with your real 2025 Positems data.

---

## What's inside

- **Dashboard** — overview of your 219 customers, revenue, tier breakdown
- **All Customers** — searchable, filterable list with tier and points
- **Customer Portal** — preview exactly what each customer sees at their link
- **Loyalty Tiers** — Bronze / Silver / Gold / VIP rules
- **Promotions & Gifts** — monthly coupons, birthday gifts, occasion messages

---

## How to deploy (step by step, no coding needed)

### Step 1 — Install Node.js (one time only)
Go to https://nodejs.org and download the LTS version. Install it.

### Step 2 — Create a GitHub account (free)
Go to https://github.com and sign up.

### Step 3 — Upload this folder to GitHub
1. Go to https://github.com/new
2. Name your repo: `sakura-shop`
3. Click "Create repository"
4. Upload all these files (drag and drop the whole folder)

### Step 4 — Create a Vercel account (free)
Go to https://vercel.com and sign up with your GitHub account.

### Step 5 — Deploy
1. In Vercel, click "Add New Project"
2. Import your `sakura-shop` repo from GitHub
3. Click "Deploy" — Vercel does everything automatically
4. Your app is live at: `sakura-shop.vercel.app` (or similar)

### Step 6 — Optional: custom domain
Buy `sakurashop.com` or similar at https://namecheap.com (~$12/year)
Connect it in Vercel under Project → Settings → Domains.

---

## Sending customer portal links

Once deployed, send each customer their link on Facebook or Instagram:

> "Hi [Name]! Here is your Sakura Shop loyalty card 🌸
> Check your points, tier, and rewards here:
> sakura-shop.vercel.app/portal → select your name"

---

## Updating customer data

When you export new data from Positems:
1. Re-run the Python script (I can do this for you)
2. Replace `src/data/customers.json`
3. Push to GitHub → Vercel auto-deploys in 2 minutes

---

## Cost summary

| Item | Cost |
|------|------|
| GitHub | Free |
| Vercel hosting | Free |
| Custom domain (optional) | ~$12/year |
| **Total** | **$0 or $12/year** |
